// ./config/config.js

const config = {
    serverAddr: '127.0.0.1',
    tcpPort: 8000,
    httpPort: 3000
  };

module.exports = config;  